package com.example.myapplication_helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //tv_hello.setText("今天天气挺好");//给tv_hello设置文字内容
        //tv_hello.setTextColor(Color.RED);//给tv_hello设置文字颜色
        //tv_hello.setTextSize(30);//给tv_hello设置文字大小
    }
    public void Welcome(View view) {
        Toast.makeText(MainActivity.this, "邓芊的第一个安卓项目", Toast.LENGTH_SHORT).show();
        Log.d("MainActivity","邓芊的第一个安卓项目");
    }


}
